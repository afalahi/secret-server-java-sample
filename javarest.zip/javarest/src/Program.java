import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.apache.commons.codec.binary.Base64;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintStream;
import java.io.Reader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.Path;

public class Program {
	
	/*
	 * Examples for using the Secret Server REST API
	 * 
	 * Instructions
	 * Replace the URL and credentials with your Secret Server information
	 * Replace the _folderId, and _exampleSecretId with example folders and secrets from your test instance
	 * These can be pulled from the query string of a Folder or Secret, i.e. SecretView.aspx?SecretId=100
	 * Uncomment a function call in the main method to test
	 * Some calls, such as creating a user will require the account logging into the API to have administrative rights
	 */
	
	public static String _activeDirectoryTemplateId = "6001";		
	public static String _folderId = "3";
	public static Integer _exampleSecretId = 63;
	public static Integer _exampleFileAttachmentSecretId = 1;
	public static String _exampleSecretFieldName = "password";
	public static String _exampleGroupName = "Security Team";

	//Replace with your URL and Secret Server Credentials
	public static String secretServerUrl = ""; //secret server url
	public static String username = ""; //API username
	public static String password = ""; //password

	public static void main(String[] args) throws Exception  {
		
		CloseableHttpClient httpclient = HttpClients.createDefault();
        try {	
        	//Authenticate or hardcoded access token here
        	String token = authenticate(httpclient, secretServerUrl, username, password);
        	
        	//search Secrets
        	//searchSecrets(httpclient, secretServerUrl, token, "");
        	
        	//search folders
        	//searchFolders(httpclient, secretServerUrl, token);
        	
        	//Create the secret JSON object from a stub
        	//JSONObject secret = createSecret(httpclient, secretServerUrl, token);
        	
        	//createSecret2(httpclient, secretServerUrl, token);
        	//Add the secret to a Folder
        	//addSecret(httpclient, secretServerUrl, token, secret);
        	
        	//Add the secret to a Folder
        	//JSONObject secret = getSecret(httpclient, secretServerUrl, token, _exampleSecretId);
        	//updateSecret(httpclient,secret, secretServerUrl, token);
        	//System.out.println(secret);
        	//Update and Get specific values from a Secret Field
        	//updateSecretField(httpclient, secretServerUrl, token, _exampleSecretId, _exampleSecretFieldName, "examplepassword");
        	//getSecretField(httpclient, secretServerUrl, token, _exampleSecretId, _exampleSecretFieldName);
        	
        	//Upload file to field
        	//uploadFile(httpclient, secretServerUrl, token, _exampleFileAttachmentSecretId, "private-key", "c:\\temp\\outfile.pem");
        	
        	//Add a user and add them to a group
        	//String testUsername = addUser(httpclient, secretServerUrl, token);
        	//Add the newly created user to a group
        	//addUserToGroup(httpclient, secretServerUrl, testUsername, _exampleGroupName, token);
        	
        	//update the created user
        	//updateUser(httpclient, secretServerUrl, testUsername, token);
        	
        } finally {
            httpclient.close();
        }
	}

	private static String authenticate(CloseableHttpClient httpclient, String secretServerUrl, String username, String password) throws Exception {
		HttpPost httpPost = new HttpPost(secretServerUrl+"/oauth2/token");
		List <NameValuePair> nvps = new ArrayList <NameValuePair>();
		nvps.add(new BasicNameValuePair("username", username));
		nvps.add(new BasicNameValuePair("password", password));
		nvps.add(new BasicNameValuePair("grant_type", "password"));
		httpPost.setEntity(new UrlEncodedFormEntity(nvps));
		
		CloseableHttpResponse response2 = httpclient.execute(httpPost);

		try {
		    System.out.println("----------Authenticating------------");
		    System.out.println(response2.getStatusLine());
		    String json = EntityUtils.toString(response2.getEntity(), "UTF-8");
		     String token = "";

		    JSONParser parser = new JSONParser();
		    Object resultObject = parser.parse(json);
		    
		    if (resultObject instanceof JSONObject) {
		        JSONObject obj =(JSONObject)resultObject;
		        if (obj.get("error") != null) {
		        	throw new Exception("Error authenticating. Ensure username / password are correct and web services are enabled");
		        }
	            token = (String) obj.get("access_token");
				System.out.println("Authentication Token:" + token);
		    }
		    return token;
		} finally {
		    response2.close();
		}
	}
	
	private static void searchSecrets(CloseableHttpClient httpclient, String secretServerUrl, String token, String searchText) throws Exception {
		
		//Specify the Secret Template ID and Folder ID to create the Secret In
		String filter = secretServerUrl+"/api/v1/secrets?filter.includeRestricted=false&filter.searchtext=%s";
		String formattedFilter = String.format(filter, searchText);

	    System.out.println("----------Search Secrets------------");
		JSONObject secretResult = getObject(httpclient, formattedFilter, token);
		JSONArray secrets = (JSONArray) secretResult.get("records");
		for (Object secret : secrets) {
			JSONObject jsonSecret =(JSONObject)secret;
			System.out.println("Found Secret: " + jsonSecret.get("name"));
		}
	    System.out.println("----------Finished Search------------");
	}
	
	private static void searchFolders(CloseableHttpClient httpclient, String secretServerUrl, String token) throws Exception {
		String formattedFilter = secretServerUrl+"/api/v1/folders";

	    System.out.println("----------Search Folders------------");
		JSONObject folderResult = getObject(httpclient, formattedFilter, token);
		JSONArray folders = (JSONArray) folderResult.get("records");
		for (Object folder : folders) {
			JSONObject jsonFolder =(JSONObject)folder;
			System.out.println("Found Folder: " + jsonFolder.get("folderName"));
		}
	    System.out.println("----------Finished Search------------");
	}
	
	private static JSONObject createSecret(CloseableHttpClient httpclient, String secretServerUrl, String token) throws Exception {
		
		//Specify the Secret Template ID and Folder ID to create the Secret In
		String filter = secretServerUrl+"/api/v1/secrets/stub?filter.secrettemplateid=%s&filter.folderId=%s";
		String formattedFilter = String.format(filter, _activeDirectoryTemplateId, _folderId);

	    System.out.println("----------Get Secret Stub------------");
		JSONObject emptySecret = getObject(httpclient, formattedFilter, token);
		
        //Specify the Secret Name and Default Site
	    String timeStamp = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new Date());
        emptySecret.put("name", "Secret: "+ timeStamp);
        //emptySecret.put("siteId", "2");
        //Fill out the field values on the Secret
        JSONArray array=(JSONArray) emptySecret.get("items");
        for (Object object : array) {
            JSONObject obj =(JSONObject)object;
            String fieldName = (String) obj.get("fieldName");
			System.out.println("Secret Field Name: " + fieldName);
			if (fieldName.toLowerCase().equals("domain")) {
				obj.put("itemValue", "domain.acmeinc.com");
			}
			if (fieldName.toLowerCase().equals("username")) {
				obj.put("itemValue", "domainusername");
			}
			if (fieldName.toLowerCase().equals("password")) {
				obj.put("itemValue",UUID.randomUUID().toString().replaceAll("-", ""));
			}
			if (fieldName.toLowerCase().equals("notes")) {
				obj.put("itemValue", "Created via API");
			}
        }
        return emptySecret;
	}
	

	private static void createSecret2(CloseableHttpClient httpclient, String secretServerUrl, String token) throws Exception {
		
		//Specify the Secret Template ID and Folder ID to create the Secret In
		secretServerUrl = secretServerUrl+"/api/v1/secrets/";

	    System.out.println("----------Add Secret------------");
		JSONObject emptySecret = new JSONObject();
	    String timeStamp = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new Date());
	    String items = "[{\"fieldname\": \"username\",\"FieldId\": \"90\",\"itemvalue\": \"blahblah\"},{\"fieldname\": \"domain\",\"FieldId\": \"87\",\"itemvalue\": \"somedomain\"},{\"fieldname\": \"notes\",\"FieldId\": \"88\",\"itemvalue\": \"\"},{\"fieldname\": \"password\",\"FieldId\": \"89\",\"itemvalue\": \"somepassword\"}]";
        emptySecret.put("siteId", "1");
        emptySecret.put("SecretTemplateId","6001");
        emptySecret.put("folderId", "3");
        //emptySecret.put("")
        emptySecret.put("name", "Secret: "+ timeStamp);
        JSONParser parser = new JSONParser();
	    JSONArray itemsArray=  (JSONArray) parser.parse(items);
	    emptySecret.put("items",itemsArray);
		addObject(httpclient, secretServerUrl, token, emptySecret);
		
		
	}
	
	private static void addSecret(CloseableHttpClient httpclient, String secretServerUrl, String token, JSONObject secretJSON) throws Exception {
		secretServerUrl = secretServerUrl+"/api/v1/secrets/";
		addObject(httpclient, secretServerUrl, token, secretJSON);
	}
	
	private static JSONObject getSecret(CloseableHttpClient httpclient, String secretServerUrl, String token, Integer secretId) throws Exception {
		secretServerUrl = secretServerUrl+"/api/v1/secrets/"+secretId +"/?args.includeInactive=true";
		
		JSONObject returnedSecret = getObject(httpclient, secretServerUrl, token);
		//System.out.println(returnedSecret.toString());

		String username = "";
		String password = "";
		String domain = "";
		JSONArray array=(JSONArray) returnedSecret.get("items");
		 for (Object object : array) {
			 	JSONObject obj =(JSONObject)object;
	            String fieldName = (String) obj.get("fieldName");
	            if (fieldName.toLowerCase().equals("username")) {
	            	username = (String) obj.get("itemValue");
				} 
	            if (fieldName.toLowerCase().equals("password")) {
	            	password = (String) obj.get("itemValue");
				}
	            if (fieldName.toLowerCase().equals("domain")) {
	            	domain = (String) obj.get("itemValue");
				}
		    }

		String secretInfo = "ID: %s Name: %s Template:%s Username:%s Domain:%s Password:%s";
		String formattedSecretInfo = String.format(secretInfo, returnedSecret.get("id"), returnedSecret.get("name"), returnedSecret.get("secretTemplateName"), username, domain, password);
		System.out.println("Found Secret: " + formattedSecretInfo);
		return returnedSecret;
	}
	
private static void updateSecret(CloseableHttpClient httpclient, JSONObject secret, String secretServerUrl, String token) throws Exception {
		
		//Specify the Secret Template ID and Folder ID to create the Secret In
		secretServerUrl = secretServerUrl+"/api/v1/secrets/"+secret.get("id");
	
        //emptySecret.put("siteId", "2");
        //Fill out the field values on the Secret
        secret.put("Active", true);
        updateObject(httpclient, secretServerUrl, token, secret);

	}

	private static String getSecretField(CloseableHttpClient httpclient, String secretServerUrl, String token, Integer secretId, String secretFieldName) throws Exception {
		secretServerUrl = secretServerUrl+"/api/v1/secrets/"+secretId+"/fields/"+secretFieldName;
		String returnedFieldValue = getValue(httpclient, secretServerUrl, token);

		String secretInfo = "Secret ID: %s FieldName: %s FieldValue: %s";
		String formattedSecretInfo = String.format(secretInfo,secretId, secretFieldName, returnedFieldValue);
		System.out.println("Found Secret: " + formattedSecretInfo);
		return secretInfo;
	}

	private static void updateSecretField(CloseableHttpClient httpclient, String secretServerUrl, String token, Integer secretId, String secretFieldName, String secretFieldValue) throws Exception {
		secretServerUrl = secretServerUrl+"/api/v1/secrets/"+secretId+"/fields/"+secretFieldName;
		setValue(httpclient, secretServerUrl, token, secretFieldValue);
	}
	
	private static void uploadFile(CloseableHttpClient httpclient, String secretServerUrl, String token, Integer secretId, String secretFieldName, String filePath) throws Exception {
		secretServerUrl = secretServerUrl+"/api/v1/secrets/"+secretId+"/fields/"+secretFieldName;
		
		Path path = Paths.get(filePath);
		byte[] data = Files.readAllBytes(path);
		//String str = new String(data, "UTF-8"); // for UTF-8 encoding
		JSONArray fileObject = new JSONArray();
		
		JSONObject fileName = new JSONObject();
		fileName.put("fileName", "keyfile.pem");
		//JSONObject fileData = new JSONObject();
		fileName.put("fileAttachment", Base64.encodeBase64String(data));
		//fileObject.add(fileName);
		//fileObject.add(fileData);
		uploadFileJSON(httpclient, secretServerUrl, token, fileName);
		
	}
	
	private static String addUser(CloseableHttpClient httpclient, String secretServerUrl, String token) throws Exception {
		secretServerUrl = secretServerUrl+"/api/v1/users/";

		//Create the user object
	    String timeStamp = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new Date());
		JSONObject userJSON = new JSONObject();	
		String username = "newuser" + timeStamp;
		userJSON.put("username", username);
		userJSON.put("password", "somerandompassword12#");
		userJSON.put("displayname", "New User: " + timeStamp);
		userJSON.put("emailaddress", "newuser@acmetest.com");
		userJSON.put("domainid", "-1"); //local domain
		userJSON.put("isapplicationaccount", "true"); //user or application account user
		userJSON.put("enabled", "false");
		
		//Uncomment different two factor options for the user
		//Two Factor (Only one form of 2FA can be enabled on a user)
		//Google Authenticator / OATH 2FA
		//userJSON.put("oathtwofactor", "true");
		
		//RADIUS
		//userJSON.put("radiususername", username);
		//userJSON.put("radiustwofactor", "true");
		
		//Duo
		//userJSON.put("duotwofactor", "true");


		addObject(httpclient, secretServerUrl, token, userJSON);
		return username;
	}
	
	private static void updateUser(CloseableHttpClient httpclient, String secretServerUrl, String userName, String token) throws Exception {
		String searchUrl = secretServerUrl+"/api/v1/users/?filter.searchtext=%s";		
		String formattedFilter = String.format(searchUrl, userName);

	    System.out.println("----------Search Users------------");
		JSONObject usersResult = getObject(httpclient, formattedFilter, token);
		JSONArray users = (JSONArray) usersResult.get("records");
		String userid = "";
		for (Object user : users) {
			JSONObject jsonUser =(JSONObject)user;
			userid =  jsonUser.get("id").toString();
			System.out.println("Found UserId: " + userid);
			break;
		}
	    System.out.println("----------Finished User Search------------");	  
	    
	    String updateUrl = secretServerUrl+"/api/v1/users/" + userid;
	    System.out.println("----------Get User------------");
		JSONObject userResult = getObject(httpclient, updateUrl, token);	
		System.out.println("User Displayname: " + userResult.get("displayName"));		
		System.out.println("User Email		: " + userResult.get("emailAddress"));		
		System.out.println("User DomainId	: " + userResult.get("domainId"));		
		System.out.println("User Enabled	: " + userResult.get("enabled"));		
	    System.out.println("----------Finished User Get------------");
	    	    
	    userResult.put("enabled", "true");
	    updateObject(httpclient, updateUrl, token, userResult);
	}
	
	private static void addUserToGroup(CloseableHttpClient httpclient, String secretServerUrl, String userName, String groupName, String token) throws Exception {
		String searchUrl = secretServerUrl+"/api/v1/users/?filter.searchtext=%s";		
		String formattedFilter = String.format(searchUrl, userName);

	    System.out.println("----------Search Users------------");
		JSONObject usersResult = getObject(httpclient, formattedFilter, token);
		JSONArray users = (JSONArray) usersResult.get("records");
		String userid = "";
		JSONObject jsonUser = null;
		for (Object user : users) {
			jsonUser =(JSONObject)user;
			userid =  jsonUser.get("id").toString();
			System.out.println("Found UserId: " + userid);
			break;
		}
	    System.out.println("----------Finished User Search------------");	  
	    
	    searchUrl = secretServerUrl+"/api/v1/groups?filter.searchtext=%s";		
		formattedFilter = String.format(searchUrl, URLEncoder.encode(groupName, "UTF-8"));

	    System.out.println("Filter: " + formattedFilter);	  
		JSONObject groupsResult = getObject(httpclient, formattedFilter, token);
		JSONArray groups = (JSONArray) groupsResult.get("records");
		String groupId = "";
		for (Object group : groups) {
			JSONObject jsonGroup =(JSONObject)group;
			groupId =  jsonGroup.get("id").toString();
			System.out.println("Found GroupId: " + groupId);
			break;
		}
		
	    String updateUrl = secretServerUrl+"/api/v1/groups/"+groupId+"/users";
	    System.out.println("----------Update User------------");
		JSONObject userUpdate = new JSONObject();
		userUpdate.put("UserId", jsonUser.get("id"));
		userUpdate.put("UserName", jsonUser.get("userName"));
	    addObject(httpclient, updateUrl, token, userUpdate);
	}
	
	
	private static void addObject(CloseableHttpClient httpclient, String secretServerUrl, String token, JSONObject object) throws Exception {
		HttpPost httpPost = new HttpPost(secretServerUrl);
		httpPost.addHeader("Content-type", "application/json");
		httpPost.addHeader("Authorization", "Bearer " + token);
		StringEntity params = new StringEntity(object.toString());
		httpPost.setEntity(params);		

	    System.out.println("-----Adding To " + secretServerUrl + "-------");
		CloseableHttpResponse response2 = httpclient.execute(httpPost);

		try {
		    System.out.println("-----Status: " + response2.getStatusLine() + "-------");
		    String json = EntityUtils.toString(response2.getEntity(), "UTF-8");
		    JSONObject resultObject = (JSONObject) new JSONParser().parse(json);
		    if (resultObject.get("message") != null) {
		    	String message = (String) resultObject.get("modelState");
		    	if (message == null) {
		    		message = (String) resultObject.get("message");
		    	}
				throw new Exception ("Error getting object: " + message);
			}     
		} finally {
		    response2.close();
		}
	} 
	
	private static void updateObject(CloseableHttpClient httpclient, String secretServerUrl, String token, JSONObject object) throws Exception {
		HttpPut httpPut = new HttpPut(secretServerUrl);
		httpPut.addHeader("Content-type", "application/json");
		httpPut.addHeader("Authorization", "Bearer " + token);
		StringEntity params = new StringEntity(object.toString());
		httpPut.setEntity(params);		

	    System.out.println("-----Updating " + secretServerUrl + "-------");
		CloseableHttpResponse response2 = httpclient.execute(httpPut);

		try {
		    System.out.println("-----Status: " + response2.getStatusLine() + "-------");
		    String json = EntityUtils.toString(response2.getEntity(), "UTF-8");
		    JSONObject resultObject = (JSONObject) new JSONParser().parse(json);
		    if (resultObject.get("message") != null) {
		    	String message = (String) resultObject.get("modelState");
		    	if (message == null) {
		    		message = (String) resultObject.get("message");
		    	}
				throw new Exception ("Error getting object: " + message);
			}     
		} finally {
		    response2.close();
		}
	} 
	
	private static JSONObject getObject(CloseableHttpClient httpclient, String secretServerUrl, String token) throws Exception {
		
		HttpGet httpGet = new HttpGet(secretServerUrl);		
		//Add bearer token to header
		httpGet.setHeader("Authorization", "Bearer " + token);
		CloseableHttpResponse response2 = httpclient.execute(httpGet);	
		try {
			//Get status of call
		    System.out.println("-----Status: " + response2.getStatusLine() + "-------");
		 	String json = EntityUtils.toString(response2.getEntity(), "UTF-8");	   
		    JSONParser parser = new JSONParser();
		    JSONObject resultObject = (JSONObject) parser.parse(json);
		    if (resultObject.get("message") != null) {
				throw new Exception ("Error getting object: " + resultObject.values());
			}
		    return resultObject;
		} finally {
			response2.close();
		}	
	}
	
	private static String getValue(CloseableHttpClient httpclient, String secretServerUrl, String token) throws Exception {
		
		HttpGet httpGet = new HttpGet(secretServerUrl);		
		//Add bearer token to header
		httpGet.setHeader("Authorization", "Bearer " + token);
		CloseableHttpResponse response2 = httpclient.execute(httpGet);	
		try {
			//Get status of call
		    System.out.println("-----Status: " + response2.getStatusLine() + "-------");
		 	String json = EntityUtils.toString(response2.getEntity(), "UTF-8");	   
		    return json;
		} finally {
			response2.close();
		}	
	}
	
	private static void setValue(CloseableHttpClient httpclient, String secretServerUrl, String token, String fieldValue) throws Exception {
		HttpPut httpPut = new HttpPut(secretServerUrl);
		httpPut.addHeader("Content-type", "application/json");
		httpPut.addHeader("Authorization", "Bearer " + token);
		JSONObject jsonObject = new JSONObject();	
		jsonObject.put("value", fieldValue);
		StringEntity params = new StringEntity(jsonObject.toString());
		httpPut.setEntity(params);		

	    System.out.println("-----Updating Value At " + secretServerUrl + "-------");
		CloseableHttpResponse response2 = httpclient.execute(httpPut);

		try {
		    System.out.println("-----Status: " + response2.getStatusLine() + "-------");
		    String json = EntityUtils.toString(response2.getEntity(), "UTF-8");
		    System.out.println("-----Field Update Status: " + json + "-------");
		        
		} finally {
		    response2.close();
		}
	} 
	
	private static void uploadFileJSON(CloseableHttpClient httpclient, String secretServerUrl, String token, JSONObject file) throws Exception {
		HttpPut httpPut = new HttpPut(secretServerUrl);
		httpPut.addHeader("Content-type", "application/json");
		httpPut.addHeader("Authorization", "Bearer " + token);
		
		StringEntity params = new StringEntity(file.toString());
		httpPut.setEntity(params);		
		

	    System.out.println("-----Uploading File At " + secretServerUrl + "-------");
		CloseableHttpResponse response2 = httpclient.execute(httpPut);

		try {
		    System.out.println("-----Status: " + response2.getStatusLine() + "-------");
		    String json = EntityUtils.toString(response2.getEntity(), "UTF-8");
		    System.out.println("-----Field Update Status: " + json + "-------");
		        
		} finally {
		    response2.close();
		}
	} 
}
