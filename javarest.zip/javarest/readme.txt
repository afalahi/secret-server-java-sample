in the main program class uncomment the method you'd like to invoke when debugging or running the project. this should serve as a sample to demonstrate how Java can interact with our rest API.
